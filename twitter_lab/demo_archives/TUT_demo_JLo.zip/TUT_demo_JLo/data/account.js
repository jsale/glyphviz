window.YTD.account.part0 = [
  {
    "account": {
      "username": "JLo",
      "accountDisplayName": "Jennifer Lopez",
      "accountId": "85603854"
    }
  }
]
