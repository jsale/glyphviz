window.YTD.accountTimezone.part0 = [
  {
    "accountTimezone": {
      "timeZone": "Pacific Time (US & Canada)"
    }
  }
]
