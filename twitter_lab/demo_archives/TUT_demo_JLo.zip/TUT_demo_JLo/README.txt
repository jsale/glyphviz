TUT demo archive — @JLo
=======================

Drop the `data` folder beside this file onto the Timeline Tower Designer, or
point the script at it:

    python tut.py --archive data --out .

3,218 posts, April 2019 to December 2021 — two and a half years, so the
tower has seasons in it. All four post kinds are here in quantity (1,516
reposts, 1,018 originals, 423 quotes, 261 replies), which makes this the
one to look at if you want to see what the needle colours are for. The
`helix` layout is worth the extra render: one turn per year, so the same
week of three different years stacks vertically. Try keywords `love,music`.

Where it came from
------------------
This is NOT an X archive download. It was rebuilt from a public Twitter/X
API v2 timeline scrape into the archive's own file format, by
`twitter_lab/v2_to_archive.py`. Nothing here is private: every post was
public when it was collected in December 2021.

Two things the v2 API could not supply, so the demo cannot either:

  * A repost's text is truncated by the API at ~140 characters. 823 of the
    1,516 reposts here end in an ellipsis. Their time, kind and counts are
    exact; their character-derived rings measure the truncation. The 1,702
    posts JLo actually wrote are complete.
  * Media attachments are absent. A photo post converts as if it carried no
    attachment. This does not affect the links ring — a real X archive does
    not list media links there either.

On the quote count: an X archive has no quote-post flag, so both the script
and the designer infer a quote from a link to another post. That reads 51 of
JLo's originals — a bare "✨✨✨" over a link to someone else's tweet — as
quotes. A real archive of the same account would say exactly the same thing;
it is the inference, not the conversion.

`account-timezone.js` is an editorial addition: the v2 timeline carries no
timezone, and Pacific is the account's home clock. Delete that file, or tick
UTC in the designer, to read the tower in UTC instead.
