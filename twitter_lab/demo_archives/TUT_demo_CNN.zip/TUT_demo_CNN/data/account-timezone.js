window.YTD.accountTimezone.part0 = [
  {
    "accountTimezone": {
      "timeZone": "Eastern Time (US & Canada)"
    }
  }
]
