window.YTD.account.part0 = [
  {
    "account": {
      "username": "CNN",
      "accountDisplayName": "CNN",
      "accountId": "759251"
    }
  }
]
