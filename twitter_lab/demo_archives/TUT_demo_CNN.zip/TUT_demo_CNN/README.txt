TUT demo archive — @CNN
=======================

Drop the `data` folder beside this file onto the Timeline Tower Designer, or
point the script at it:

    python tut.py --archive data --out .

3,248 posts, 13 Nov to 21 Dec 2021 — five weeks of a newsroom at full tilt.
Clocked in Eastern Time, so the bearing ring reads as a real newsroom day:
the tower is thinnest around 3am and thickest through the afternoon and
evening. Almost every post is an original, so the needle colour is nearly
uniform and the rings carry the whole story. Try keywords `covid,climate`.

Where it came from
------------------
This is NOT an X archive download. It was rebuilt from a public Twitter/X
API v2 timeline scrape into the archive's own file format, by
`twitter_lab/v2_to_archive.py`. Nothing here is private: every post was
public when it was collected in December 2021.

Two things the v2 API could not supply, so the demo cannot either:

  * A repost's text is truncated by the API at ~140 characters. 74 of the 78
    reposts here end in an ellipsis. Their time, kind and counts are exact;
    their character-derived rings measure the truncation. The 3,170 posts CNN
    actually wrote are complete.
  * Media attachments are absent. A photo post converts as if it carried no
    attachment. This does not affect the links ring — a real X archive does
    not list media links there either.

`account-timezone.js` is an editorial addition: the v2 timeline carries no
timezone, and Eastern is CNN's newsroom clock. Delete that file, or tick UTC
in the designer, to read the tower in UTC instead.
